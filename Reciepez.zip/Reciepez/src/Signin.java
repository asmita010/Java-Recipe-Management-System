import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextArea;


import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Signin {

	 JFrame frame;
	 private JPasswordField t2;
	 private JPasswordField t3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Signin window = new Signin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Signin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Signin.class.getResource("/Images/User.png")));
		lblNewLabel.setBounds(137, 132, 247, 295);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblSigninAsNew = new JLabel("Sign-In as New User");
		lblSigninAsNew.setForeground(new Color(199, 21, 133));
		lblSigninAsNew.setFont(new Font("Gill Sans MT", Font.BOLD, 40));
		lblSigninAsNew.setBounds(710, 85, 446, 48);
		frame.getContentPane().add(lblSigninAsNew);
		
		JLabel label_1 = new JLabel("Enter Username");
		label_1.setForeground(new Color(165, 42, 42));
		label_1.setFont(new Font("Andalus", Font.BOLD, 30));
		label_1.setBounds(603, 208, 283, 30);
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("Enter Password");
		label_2.setForeground(new Color(165, 42, 42));
		label_2.setFont(new Font("Andalus", Font.BOLD, 30));
		label_2.setBounds(603, 325, 218, 30);
		frame.getContentPane().add(label_2);
		
		JTextArea t1 = new JTextArea();
		t1.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		t1.setBackground(new Color(224, 255, 255));
		t1.setBounds(929, 213, 361, 30);
		frame.getContentPane().add(t1);
		
		JButton b = new JButton("Click To Sign-In");
		
		b.setForeground(new Color(0, 51, 153));
		b.setFont(new Font("Arial", Font.BOLD, 26));
		b.setBackground(Color.WHITE);
		b.setBounds(788, 550, 233, 41);
		frame.getContentPane().add(b);
		
		JLabel label = new JLabel("Reciepez");
		label.setForeground(new Color(255, 204, 0));
		label.setFont(new Font("Poor Richard", Font.BOLD, 55));
		label.setBounds(149, 63, 283, 58);
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome To Recipez !!!");
		lblNewLabel_1.setForeground(new Color(255, 153, 204));
		lblNewLabel_1.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(1034, 632, 283, 30);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Unlimited Access To Thousands Of");
		lblNewLabel_2.setForeground(new Color(204, 204, 0));
		lblNewLabel_2.setFont(new Font("Gabriola", Font.BOLD, 25));
		lblNewLabel_2.setBounds(116, 420, 316, 30);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblHealthyAndEasy = new JLabel("Healthy And Easy Recipes");
		lblHealthyAndEasy.setForeground(new Color(204, 204, 0));
		lblHealthyAndEasy.setFont(new Font("Gabriola", Font.BOLD, 25));
		lblHealthyAndEasy.setBounds(149, 450, 233, 30);
		frame.getContentPane().add(lblHealthyAndEasy);
		
		JLabel lblReenterPassword = new JLabel("Re-Enter Password");
		lblReenterPassword.setForeground(new Color(165, 42, 42));
		lblReenterPassword.setFont(new Font("Andalus", Font.BOLD, 30));
		lblReenterPassword.setBounds(603, 444, 283, 30);
		frame.getContentPane().add(lblReenterPassword);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Signin.class.getResource("/Images/Cook-Book-icon.png")));
		lblNewLabel_3.setBounds(39, 534, 150, 128);
		frame.getContentPane().add(lblNewLabel_3);
		
		t2 = new JPasswordField();
		t2.setBackground(new Color(224, 255, 255));
		t2.setBounds(929, 325, 361, 30);
		frame.getContentPane().add(t2);
		
		t3 = new JPasswordField();
		t3.setBackground(new Color(224, 255, 255));
		t3.setBounds(929, 444, 361, 30);
		frame.getContentPane().add(t3);
		
		
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String name=t1.getText();
				
				char[] passArray=t2.getPassword();
				String pass=String.valueOf(passArray);
				
				char[] passArray1=t3.getPassword();
				String pass2=String.valueOf(passArray1);
				
				
				int c=0;
				Pattern sp=Pattern.compile("[^a-z)-9]",Pattern.CASE_INSENSITIVE);

				if(pass.length()<8)
					JOptionPane.showMessageDialog(frame, "Password should contain atleast 8 characters", "Invalid Password", JOptionPane.ERROR_MESSAGE);
				else if(!sp.matcher(pass).find())
				{
					JOptionPane.showMessageDialog(frame, "Password should contain atleast 1 symbol", "Invalid Password", JOptionPane.ERROR_MESSAGE);
				for(int i=0;i<=9;i++)
				{
					String str=Integer.toString(i);
					if(pass.contains(str))
						c=1;
				}
				if(c==0)
					JOptionPane.showMessageDialog(frame, "Password should contain atleast 1 Numeric Digit", "Invalid Password", JOptionPane.ERROR_MESSAGE);
				}
				else if(!pass.equals(pass2))
				{
					JOptionPane.showMessageDialog(frame, "Password does not match", "Invalid Password", JOptionPane.ERROR_MESSAGE);

				}
				else{
				
					 String url="jdbc:oracle:thin:@localhost:1521:xe";
						String username="username";
						String password="password";
						//String role="student";
						String s5="smuser.nextval";
						String role="user";
						try
						{
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con = DriverManager.getConnection(url,username,password);
						
					
						String query="insert into ruser values(rsuserno.nextval,'"+name+"','"+pass+"','"+role+"')";

						
						PreparedStatement sta=con.prepareStatement(query);
						
						int count=sta.executeUpdate();
						sta.close();
						con.close();
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
						
						frame.dispose();
						Login l = new Login();
						l.frame.setVisible(true);
				}
				
				
				
				
				
			}
		});
		
	}
}
