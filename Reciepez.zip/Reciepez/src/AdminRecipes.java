import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class AdminRecipes {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminRecipes window = new AdminRecipes();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminRecipes() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton button = new JButton("Go Back To Main Page");
		button.setForeground(new Color(0, 51, 153));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				AdminMenu u=new AdminMenu();
				u.frame.setVisible(true);
			}
		});
		button.setFont(new Font("Shruti", Font.PLAIN, 22));
		button.setBounds(39, 22, 276, 33);
		frame.getContentPane().add(button);
		
		JLabel lblListOfAll = new JLabel("List Of All Recipes");
		lblListOfAll.setForeground(new Color(204, 0, 153));
		lblListOfAll.setFont(new Font("Narkisim", Font.BOLD, 28));
		lblListOfAll.setBounds(570, 63, 248, 39);
		frame.getContentPane().add(lblListOfAll);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(255, 143, 835, 442);
		frame.getContentPane().add(scrollPane);
		
		JList list = new JList();
		list.setFont(new Font("Shruti", Font.PLAIN, 20));
		scrollPane.setViewportView(list);
		
		JButton btnDeleteRecipe = new JButton("Delete Recipe");
		btnDeleteRecipe.setForeground(new Color(0, 51, 153));
		btnDeleteRecipe.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st1=con1.createStatement();
					String sql = "select name from rrecipe";
					ResultSet r=st1.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    list.setModel(dlm);
				    
			   
				    
				}
				    catch(Exception e)
				    {
				    	e.printStackTrace();
				    }
			}
		});
		
		btnDeleteRecipe.setFont(new Font("Shruti", Font.PLAIN, 22));
		btnDeleteRecipe.setBounds(564, 615, 217, 33);
		frame.getContentPane().add(btnDeleteRecipe);
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select name from rrecipe";
			ResultSet r=st1.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    list.setModel(dlm);
		    
		    JLabel label = new JLabel("Recipez");
		    label.setForeground(new Color(255, 204, 0));
		    label.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		    label.setBounds(1208, 625, 109, 37);
		    frame.getContentPane().add(label);
		    
		   
		    
		}
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
		
		
		btnDeleteRecipe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String a=(String) list.getSelectedValue();
		    	 String url="jdbc:oracle:thin:@localhost:1521:xe";
					String username="username";
					String password="password";
					//String role="student";
					String s5="smuser.nextval";
					String role="user";
					try
					{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection(url,username,password);
					
				
					String sql = "delete from  rrecipe where name='"+a+"'";

					
					PreparedStatement sta=con.prepareStatement(sql);
					
					int count=sta.executeUpdate();
					sta.close();
					con.close();
					}
					catch(Exception ae)
					{
						ae.printStackTrace();
					}
			}
		});
		
		
		
		
		
	}
}
