import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;

public class AdminMenu {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminMenu window = new AdminMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Delete Users");
		btnNewButton.setForeground(new Color(102, 153, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				AdminUsers a=new AdminUsers();
				a.frame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("SansSerif", Font.BOLD, 22));
		btnNewButton.setBounds(578, 325, 190, 37);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnRecipes = new JButton("Delete Recipes");
		btnRecipes.setForeground(new Color(51, 102, 153));
		btnRecipes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				AdminRecipes a=new AdminRecipes();
				a.frame.setVisible(true);
			}
		});
		btnRecipes.setFont(new Font("SansSerif", Font.BOLD, 22));
		btnRecipes.setBounds(949, 325, 197, 37);
		frame.getContentPane().add(btnRecipes);
		
		JButton btnViewRecipes = new JButton("View Recipes");
		btnViewRecipes.setForeground(new Color(0, 51, 153));
		btnViewRecipes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			frame.dispose();
			AdminSearch n=new AdminSearch();
			n.frame.setVisible(true);
			}
		});
		btnViewRecipes.setFont(new Font("SansSerif", Font.BOLD, 22));
		btnViewRecipes.setBounds(188, 325, 190, 37);
		frame.getContentPane().add(btnViewRecipes);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(AdminMenu.class.getResource("/Images/delete-contact-folded-icon.png")));
		lblNewLabel.setBounds(616, 196, 108, 105);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(AdminMenu.class.getResource("/Images/r.png")));
		label.setBounds(216, 196, 128, 105);
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(AdminMenu.class.getResource("/Images/close-icon.png")));
		lblNewLabel_1.setBounds(1009, 205, 96, 96);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Recipez");
		lblNewLabel_2.setForeground(new Color(255, 204, 0));
		lblNewLabel_2.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		lblNewLabel_2.setBounds(1186, 628, 119, 37);
		frame.getContentPane().add(lblNewLabel_2);
	}
}
