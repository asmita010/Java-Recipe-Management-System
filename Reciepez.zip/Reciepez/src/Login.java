import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextArea;

import oracle.jdbc.OracleDriver;

import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Login {

	 JFrame frame;
	private JPasswordField t2;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Login() {
		initialize();
	}

	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/Images/Cooking-icon.png")));
		lblNewLabel.setBounds(67, 155, 529, 469);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Reciepez");
		lblNewLabel_1.setForeground(new Color(255, 204, 0));
		lblNewLabel_1.setFont(new Font("Poor Richard", Font.BOLD, 48));
		lblNewLabel_1.setBounds(221, 43, 283, 58);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Log-In");
		lblNewLabel_2.setForeground(new Color(199, 21, 133));
		lblNewLabel_2.setFont(new Font("Gill Sans MT", Font.PLAIN, 40));
		lblNewLabel_2.setBounds(982, 60, 218, 48);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Enter Username");
		lblNewLabel_3.setForeground(new Color(165, 42, 42));
		lblNewLabel_3.setFont(new Font("Andalus", Font.BOLD, 30));
		lblNewLabel_3.setBounds(762, 165, 248, 30);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblEnterPassword = new JLabel("Enter Password");
		lblEnterPassword.setForeground(new Color(165, 42, 42));
		lblEnterPassword.setFont(new Font("Andalus", Font.BOLD, 30));
		lblEnterPassword.setBounds(762, 280, 218, 30);
		frame.getContentPane().add(lblEnterPassword);
		
		JLabel lblLogInAs = new JLabel("Log in as");
		lblLogInAs.setForeground(new Color(165, 42, 42));
		lblLogInAs.setFont(new Font("Andalus", Font.BOLD, 30));
		lblLogInAs.setBounds(763, 377, 152, 41);
		frame.getContentPane().add(lblLogInAs);
		
		JTextArea t1 = new JTextArea();
		t1.setBackground(new Color(224, 255, 255));
		t1.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
		t1.setBounds(1008, 160, 316, 40);
		frame.getContentPane().add(t1);
		
		JRadioButton r1 = new JRadioButton("User");
		r1.setForeground(new Color(128, 128, 0));
		r1.setFont(new Font("Andalus", Font.BOLD, 30));
		r1.setBounds(947, 378, 109, 39);
		frame.getContentPane().add(r1);
		
		JRadioButton r2 = new JRadioButton("Admin");
		r2.setForeground(new Color(128, 128, 0));
		r2.setFont(new Font("Andalus", Font.BOLD, 30));
		r2.setBounds(1095, 378, 131, 39);
		frame.getContentPane().add(r2);
		
		JButton btnNewButton = new JButton("Click To Log-In");
		
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setForeground(new Color(0, 51, 153));
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 26));
		btnNewButton.setBounds(910, 522, 233, 41);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_4 = new JLabel("If you do not have an account ->");
		lblNewLabel_4.setForeground(new Color(165, 42, 42));
		lblNewLabel_4.setFont(new Font("Arial", Font.BOLD, 25));
		lblNewLabel_4.setBounds(762, 610, 380, 30);
		frame.getContentPane().add(lblNewLabel_4);
		
		JButton btnNewButton_1 = new JButton("Sign In");
		
		btnNewButton_1.setForeground(new Color(0, 51, 153));
		btnNewButton_1.setFont(new Font("Andalus", Font.BOLD, 25));
		btnNewButton_1.setBounds(1151, 599, 124, 41);
		frame.getContentPane().add(btnNewButton_1);
		
		t2 = new JPasswordField();
		t2.setBackground(new Color(224, 255, 255));
		t2.setBounds(1008, 270, 316, 40);
		frame.getContentPane().add(t2);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		
		JLabel l = new JLabel("\r\n");
		l.setForeground(new Color(153, 0, 102));
		l.setFont(new Font("Andalus", Font.PLAIN, 30));
		l.setBounds(762, 466, 464, 30);
		frame.getContentPane().add(l);
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Signin s = new Signin();
				s.frame.setVisible(true);
			}
			
		});
		
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				
				String user=t1.getText();
				
				char[] passArray=t2.getPassword();
				String password=String.valueOf(passArray);
			
				
				String role="user";
				
				
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("select * from ruser");
					
					while(rs.next())
					{
						String dbuser=rs.getString(2);
						String dbpassword=rs.getString(3);
						String dbrole=rs.getString(4);
						if(dbuser.equals(user) && dbpassword.equals(password))
						{
							
							
							if(r1.isSelected())
							{
								role="user";
								if(dbrole.equals(role))
								{
									try {
									
									Class.forName("oracle.jdbc.driver.OracleDriver");
									Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
									Statement st1=con1.createStatement();
									String sql = "select userno from ruser where username='"+user+"'";
									ResultSet r=st1.executeQuery(sql);
								    while (r.next()){
								    	String aa=r.getString(1);
								    	int studid = Integer.parseInt(aa);
								    	frame.dispose();
								    	
								    	UserMenu u=new UserMenu(studid);
								    	u.frame.setVisible(true);
								    	
								    }
								    
								st1.close();
							    con1.close();
								}	
							    catch(Exception e)
									{
										e.printStackTrace();
									}
								}
								
							}
							else if(r2.isSelected())
							{
								role="admin";
								if(dbrole.equals(role))
								{
								try {
									
									Class.forName("oracle.jdbc.driver.OracleDriver");
									Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
								Statement st1=con1.createStatement();
									String sql = "select userno from ruser where username='"+user+"'";
									ResultSet r=st1.executeQuery(sql);
								    while (r.next()){
								    	String aa=r.getString(1);
								    	int studid = Integer.parseInt(aa);
								    	frame.dispose();
								    	AdminMenu a=new AdminMenu();
								    	a.frame.setVisible(true);
								    	
							    	
								    }
								    
								st1.close();
							    con1.close();
								}	
							    catch(Exception e)
									{
										e.printStackTrace();
									}
								}
							}
							else
							{
								l.setText("Please Select Role");
							}
						}
						else
						{
							l.setText("Invalid Username or Password");
						}
					}
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
				
				
				
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
