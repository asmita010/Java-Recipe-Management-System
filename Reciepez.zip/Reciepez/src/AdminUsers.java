import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JLabel;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class AdminUsers {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminUsers window = new AdminUsers();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 */
	public AdminUsers() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(255, 143, 835, 442);
		frame.getContentPane().add(scrollPane);
		
		JList list = new JList();
		list.setFont(new Font("Shruti", Font.PLAIN, 20));
		scrollPane.setViewportView(list);
		
		JButton btnNewButton = new JButton("Go Back To Main Page");
		btnNewButton.setForeground(new Color(0, 51, 153));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				AdminMenu u=new AdminMenu();
				u.frame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Shruti", Font.PLAIN, 22));
		btnNewButton.setBounds(39, 22, 276, 33);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("List Of All Users");
		lblNewLabel.setForeground(new Color(204, 0, 153));
		lblNewLabel.setFont(new Font("Narkisim", Font.BOLD, 28));
		lblNewLabel.setBounds(570, 63, 248, 39);
		frame.getContentPane().add(lblNewLabel);
		
		 JButton btnDeleteUser = new JButton("Delete User");
		 btnDeleteUser.setForeground(new Color(0, 51, 153));
		 btnDeleteUser.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st1=con1.createStatement();
					String sql = "select username from ruser where role='user'";
					ResultSet r=st1.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    list.setModel(dlm);
				    
				   
				    btnDeleteUser.setFont(new Font("Shruti", Font.PLAIN, 22));
				    btnDeleteUser.setBounds(564, 615, 217, 33);
				    frame.getContentPane().add(btnDeleteUser);
				}
				    catch(Exception a)
				    {
				    	a.printStackTrace();
				    }
				
		 	}
		 });
		   
		    
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select username from ruser where role='user'";
			ResultSet r=st1.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    list.setModel(dlm);
		    
		   
		    btnDeleteUser.setFont(new Font("Shruti", Font.PLAIN, 22));
		    btnDeleteUser.setBounds(564, 615, 217, 33);
		    frame.getContentPane().add(btnDeleteUser);
		}
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
		
		 btnDeleteUser.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e) {
		    	String a=(String) list.getSelectedValue();
		    	 String url="jdbc:oracle:thin:@localhost:1521:xe";
					String username="username";
					String password="password";
					//String role="student";
					String s5="smuser.nextval";
					String role="user";
					try
					{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection(url,username,password);
					
				
					
					String query="delete from rrecipe where userno in (select userno from ruser where username='"+a+"')";
					String sql = "delete from  ruser where username='"+a+"'";

					PreparedStatement sta=con.prepareStatement(sql);
					PreparedStatement sta1=con.prepareStatement(query);
					int count=sta1.executeUpdate();
					int count1=sta.executeUpdate();
					sta.close();
					sta1.close();
					con.close();
					}
					catch(Exception ae)
					{
						ae.printStackTrace();
					}
		    	}
		    });
	
		 
		
		
	}
}
