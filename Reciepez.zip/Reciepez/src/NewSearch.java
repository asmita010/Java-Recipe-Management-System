import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class NewSearch {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewSearch window = new NewSearch(0,null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NewSearch(int userid,String name) {
		initialize(userid,name);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int userid,String name) {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(287, 23, 771, 52);
		frame.getContentPane().add(scrollPane);
		
		JLabel l1 = new JLabel("");
		l1.setForeground(new Color(0, 102, 0));
		l1.setFont(new Font("Gisha", Font.BOLD, 24));
		l1.setHorizontalAlignment(SwingConstants.CENTER);
		scrollPane.setViewportView(l1);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(70, 145, 1237, 141);
		frame.getContentPane().add(scrollPane_1);
		
		JTextArea l2 = new JTextArea();
		l2.setForeground(new Color(102, 51, 153));
		l2.setEditable(false);
		l2.setFont(new Font("Gisha", Font.BOLD, 20));
		scrollPane_1.setViewportView(l2);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(70, 347, 1237, 309);
		frame.getContentPane().add(scrollPane_2);
		
		JTextArea l3 = new JTextArea();
		l3.setForeground(new Color(204, 0, 0));
		l3.setEditable(false);
		l3.setFont(new Font("Gisha", Font.BOLD, 20));
		scrollPane_2.setViewportView(l3);
		
		JLabel lblNewLabel_1 = new JLabel("Ingredients");
		lblNewLabel_1.setForeground(new Color(204, 0, 153));
		lblNewLabel_1.setFont(new Font("Rockwell", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(602, 98, 142, 33);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblRecipe = new JLabel("Recipe");
		lblRecipe.setForeground(new Color(204, 0, 153));
		lblRecipe.setFont(new Font("Rockwell", Font.PLAIN, 25));
		lblRecipe.setBounds(619, 303, 97, 33);
		frame.getContentPane().add(lblRecipe);
		
		JButton btnNewButton = new JButton("Go Back");
		btnNewButton.setForeground(new Color(0, 51, 153));
		
		btnNewButton.setFont(new Font("Shruti", Font.PLAIN, 22));
		btnNewButton.setBounds(26, 22, 131, 33);
		frame.getContentPane().add(btnNewButton);
		
		JLabel label = new JLabel("Recipez");
		label.setForeground(new Color(255, 204, 0));
		label.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
		label.setBounds(1251, 654, 85, 33);
		frame.getContentPane().add(label);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select INGREDIENTS from rrecipe where name='"+name+"'";
			ResultSet r=st1.executeQuery(sql);
			
		    while (r.next()){
			l2.setText(r.getString(1));
		    }
		   
		}
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
		l1.setText(name);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select RECIPE from rrecipe where name='"+name+"'";
			ResultSet r=st1.executeQuery(sql);
			
		    while (r.next()){
			l3.setText(r.getString(1));
		    }
		  
		}
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				SearchRecipe s=new SearchRecipe(userid);
				s.frame.setVisible(true);
			}
		});
	}
}
