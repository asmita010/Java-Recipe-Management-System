import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Color;

public class NewAdminSearch {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewAdminSearch window = new NewAdminSearch(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NewAdminSearch(String name) {
		initialize(name);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String name) {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Go Back");
		btnNewButton.setForeground(new Color(0, 51, 153));
		btnNewButton.setFont(new Font("Shruti", Font.PLAIN, 22));
		btnNewButton.setBounds(26, 21, 131, 33);
		frame.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(287, 23, 771, 52);
		frame.getContentPane().add(scrollPane);
		
		JTextArea l1 = new JTextArea();
		l1.setForeground(new Color(0, 102, 0));
		l1.setText("<dynamic>");
		l1.setFont(new Font("Gisha", Font.BOLD, 20));
		l1.setEditable(false);
		scrollPane.setViewportView(l1);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(70, 145, 1237, 141);
		frame.getContentPane().add(scrollPane_1);
		
		JTextArea l2 = new JTextArea();
		l2.setForeground(new Color(102, 51, 153));
		l2.setFont(new Font("Gisha", Font.BOLD, 20));
		l2.setEditable(false);
		scrollPane_1.setViewportView(l2);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(70, 347, 1237, 301);
		frame.getContentPane().add(scrollPane_3);
		
		JTextArea l3 = new JTextArea();
		l3.setForeground(new Color(204, 0, 0));
		l3.setFont(new Font("Gisha", Font.BOLD, 20));
		l3.setEditable(false);
		scrollPane_3.setViewportView(l3);
		
		JLabel label = new JLabel("Ingredients");
		label.setForeground(new Color(204, 0, 153));
		label.setFont(new Font("Rockwell", Font.PLAIN, 25));
		label.setBounds(602, 97, 142, 33);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("Recipe");
		label_1.setForeground(new Color(204, 0, 153));
		label_1.setFont(new Font("Rockwell", Font.PLAIN, 25));
		label_1.setBounds(619, 303, 97, 33);
		frame.getContentPane().add(label_1);
		
		l1.setText(name);
		
		JLabel label_2 = new JLabel("Recipez");
		label_2.setForeground(new Color(255, 204, 0));
		label_2.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
		label_2.setBounds(1248, 648, 88, 28);
		frame.getContentPane().add(label_2);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select INGREDIENTS from rrecipe where name='"+name+"'";
			ResultSet r=st1.executeQuery(sql);
			
		    while (r.next()){
			l2.setText(r.getString(1));
		    }
		   
		}
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select RECIPE from rrecipe where name='"+name+"'";
			ResultSet r=st1.executeQuery(sql);
			
		    while (r.next()){
			l3.setText(r.getString(1));
		    }
		  
		}
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();

				AdminSearch s=new AdminSearch();
				s.frame.setVisible(true);
			}
		});
		
		
		
	}
}
