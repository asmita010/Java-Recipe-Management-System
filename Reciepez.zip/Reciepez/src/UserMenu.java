import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import java.awt.Color;

public class UserMenu {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserMenu window = new UserMenu(0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserMenu(int userid) {
		initialize(userid);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int userid) {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton b1 = new JButton("New Recipe");
		b1.setForeground(new Color(255, 0, 0));
		b1.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 20));
		
		b1.setBounds(381, 354, 185, 45);
		frame.getContentPane().add(b1);
		
		JButton b2 = new JButton("Delete Recipe");
		b2.setForeground(new Color(102, 51, 153));
		b2.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 20));
		
		b2.setBounds(1071, 354, 200, 45);
		frame.getContentPane().add(b2);
		
		JButton b3 = new JButton("Edit Recipe");
		b3.setForeground(new Color(0, 102, 0));
		b3.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 20));
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				EditRecipe ed = new EditRecipe(userid);
				ed.frame.setVisible(true);
			}
		});
		b3.setBounds(739, 354, 169, 45);
		frame.getContentPane().add(b3);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(UserMenu.class.getResource("/Images/Food-Dome-icon.png")));
		lblNewLabel.setBounds(24, 530, 157, 146);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome To Recipez,");
		lblNewLabel_1.setForeground(new Color(255, 192, 203));
		lblNewLabel_1.setFont(new Font("Broadway", Font.PLAIN, 24));
		lblNewLabel_1.setBounds(55, 41, 385, 30);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel l = new JLabel("");
		l.setForeground(new Color(255, 192, 203));
		l.setFont(new Font("Broadway", Font.PLAIN, 24));
		l.setBounds(337, 41, 299, 30);
		frame.getContentPane().add(l);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(UserMenu.class.getResource("/Images/Mayor-Fork-Knife-icon.png")));
		lblNewLabel_2.setBounds(396, 190, 143, 114);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(UserMenu.class.getResource("/Images/note-edit-icon.png")));
		label.setBounds(739, 204, 143, 114);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(UserMenu.class.getResource("/Images/Trash-empty-icon.png")));
		label_1.setBounds(1105, 204, 143, 114);
		frame.getContentPane().add(label_1);
		
		JButton btnViewRecipes = new JButton("View Recipes");
		btnViewRecipes.setForeground(new Color(0, 51, 153));
		
		btnViewRecipes.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 20));
		btnViewRecipes.setBounds(55, 354, 185, 45);
		frame.getContentPane().add(btnViewRecipes);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(UserMenu.class.getResource("/Images/Steak-icon.png")));
		lblNewLabel_3.setBounds(77, 204, 143, 114);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel label_2 = new JLabel("Recipez");
		label_2.setForeground(new Color(255, 204, 0));
		label_2.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		label_2.setBounds(1217, 639, 119, 37);
		frame.getContentPane().add(label_2);
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select username from ruser where userno='"+userid+"'";
			ResultSet r=st1.executeQuery(sql);
		    while (r.next()){
		    l.setText(r.getString(1));
		    }
		   
		  
		    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		
		
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				NewReciepe n = new NewReciepe(userid);
				n.frame.setVisible(true);
			}
		});
		
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				DeleteRecipe d=new DeleteRecipe(userid);
				d.frame.setVisible(true);
			}
		});
		
		
		btnViewRecipes.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		frame.dispose();
			SearchRecipe s=new SearchRecipe(userid);
				s.frame.setVisible(true);
			}
		});
		
		
	}
}
