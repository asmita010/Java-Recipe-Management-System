import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;

public class NewReciepe {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewReciepe window = new NewReciepe(0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NewReciepe(int userid) {
		initialize(userid);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int userid) {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New Recipe");
		lblNewLabel.setForeground(new Color(204, 0, 153));
		lblNewLabel.setFont(new Font("Shruti", Font.BOLD, 35));
		lblNewLabel.setBounds(518, 34, 312, 42);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(NewReciepe.class.getResource("/Images/Diary-Recipe-icon.png")));
		lblNewLabel_1.setBounds(77, 516, 160, 128);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Enter Recipe's Name");
		lblNewLabel_2.setForeground(new Color(153, 51, 0));
		lblNewLabel_2.setFont(new Font("Baskerville Old Face", Font.BOLD, 30));
		lblNewLabel_2.setBounds(82, 111, 354, 36);
		frame.getContentPane().add(lblNewLabel_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(434, 203, 777, 116);
		frame.getContentPane().add(scrollPane);
		
		JTextArea t2 = new JTextArea();
		t2.setForeground(new Color(102, 51, 153));
		t2.setFont(new Font("Nyala", Font.PLAIN, 27));
		scrollPane.setViewportView(t2);
		
		JLabel lblEnterIngredients = new JLabel("Enter Ingredients");
		lblEnterIngredients.setForeground(new Color(153, 51, 0));
		lblEnterIngredients.setFont(new Font("Baskerville Old Face", Font.BOLD, 30));
		lblEnterIngredients.setBounds(82, 202, 354, 36);
		frame.getContentPane().add(lblEnterIngredients);
		
		JLabel lblEnterRecipe = new JLabel("Enter Recipe");
		lblEnterRecipe.setForeground(new Color(153, 51, 0));
		lblEnterRecipe.setFont(new Font("Baskerville Old Face", Font.BOLD, 30));
		lblEnterRecipe.setBounds(82, 360, 354, 36);
		frame.getContentPane().add(lblEnterRecipe);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(434, 361, 777, 205);
		frame.getContentPane().add(scrollPane_1);
		
		JTextArea t3 = new JTextArea();
		t3.setForeground(new Color(204, 51, 0));
		t3.setFont(new Font("Nyala", Font.PLAIN, 27));
		scrollPane_1.setViewportView(t3);
		
		JButton btnNewButton = new JButton("Submit Recipe");
		btnNewButton.setForeground(new Color(0, 51, 153));
		
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 22));
		btnNewButton.setBounds(561, 602, 223, 42);
		frame.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(434, 112, 777, 36);
		frame.getContentPane().add(scrollPane_2);
		
		JTextArea t1 = new JTextArea();
		t1.setForeground(new Color(51, 102, 0));
		t1.setFont(new Font("Nyala", Font.PLAIN, 27));
		scrollPane_2.setViewportView(t1);
		
		JButton b = new JButton("Go Back To Main Page");
		b.setForeground(new Color(0, 51, 153));
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				UserMenu u=new UserMenu(userid);
				u.frame.setVisible(true);
			}
		});
		b.setFont(new Font("Shruti", Font.PLAIN, 22));
		b.setBounds(33, 34, 263, 36);
		frame.getContentPane().add(b);
		
		JLabel label = new JLabel("Recipez");
		label.setForeground(new Color(255, 204, 0));
		label.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		label.setBounds(1217, 639, 119, 37);
		frame.getContentPane().add(label);
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String rname=t1.getText();
			String ring=t2.getText();
			String rrecipe=t3.getText();
			

			 String url="jdbc:oracle:thin:@localhost:1521:xe";
				String username="username";
				String password="password";
				String userno=String.valueOf(userid);
				try
				{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection(url,username,password);
				
		
				String query="insert into rrecipe values(rsrecipeno.nextval,'"+rname+"','"+ring+"','"+rrecipe+"','"+userno+"')";
				System.out.println(query);
				
				PreparedStatement sta=con.prepareStatement(query);
				
				int count=sta.executeUpdate();
				sta.close();
				con.close();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				frame.dispose();
				UserMenu u=new UserMenu(userid);
				u.frame.setVisible(true);
			
			}
		});
		
		
		
	}
}
