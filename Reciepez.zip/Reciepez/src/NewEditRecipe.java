import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class NewEditRecipe {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewEditRecipe window = new NewEditRecipe(0,null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NewEditRecipe(int userid,String name) {
		initialize(userid,name);
	}

	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int userid,String name) {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblEditRecipe = new JLabel("Edit Recipe");
		lblEditRecipe.setForeground(new Color(204, 0, 153));
		lblEditRecipe.setFont(new Font("Shruti", Font.BOLD, 35));
		lblEditRecipe.setBounds(518, 34, 312, 42);
		frame.getContentPane().add(lblEditRecipe);
		
		JLabel label_1 = new JLabel("Enter Recipe's Name");
		label_1.setForeground(new Color(153, 51, 0));
		label_1.setFont(new Font("Baskerville Old Face", Font.BOLD, 30));
		label_1.setBounds(82, 111, 354, 36);
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("Enter Ingredients");
		label_2.setForeground(new Color(153, 51, 0));
		label_2.setFont(new Font("Baskerville Old Face", Font.BOLD, 30));
		label_2.setBounds(82, 202, 354, 36);
		frame.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("Enter Recipe");
		label_3.setForeground(new Color(153, 51, 0));
		label_3.setFont(new Font("Baskerville Old Face", Font.BOLD, 30));
		label_3.setBounds(82, 360, 354, 36);
		frame.getContentPane().add(label_3);
		
		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon(NewEditRecipe.class.getResource("/Images/Diary-Recipe-icon.png")));
		label_4.setBounds(77, 516, 160, 128);
		frame.getContentPane().add(label_4);
		
		JButton b = new JButton("Submit Recipe");
		b.setForeground(new Color(0, 51, 153));
		
		b.setFont(new Font("Times New Roman", Font.BOLD, 22));
		b.setBounds(561, 602, 223, 42);
		frame.getContentPane().add(b);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(434, 203, 777, 116);
		frame.getContentPane().add(scrollPane);
		
		JTextArea t2 = new JTextArea();
		t2.setForeground(new Color(102, 51, 153));
		t2.setFont(new Font("Lucida Sans", Font.PLAIN, 20));
		scrollPane.setViewportView(t2);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(434, 361, 777, 205);
		frame.getContentPane().add(scrollPane_1);
		
		JTextArea t3 = new JTextArea();
		t3.setForeground(new Color(204, 0, 0));
		t3.setFont(new Font("Lucida Sans", Font.PLAIN, 20));
		scrollPane_1.setViewportView(t3);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(434, 112, 777, 36);
		frame.getContentPane().add(scrollPane_2);
		
		JTextArea t1 = new JTextArea();
		t1.setForeground(new Color(0, 102, 0));
		t1.setFont(new Font("Lucida Sans", Font.PLAIN, 20));
		scrollPane_2.setViewportView(t1);
		
		t1.setText(name);
		
		JLabel label = new JLabel("Recipez");
		label.setForeground(new Color(255, 204, 0));
		label.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		label.setBounds(1205, 620, 119, 37);
		frame.getContentPane().add(label);
		
		JButton btnGoBack = new JButton("Go Back");
		btnGoBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EditRecipe e=new EditRecipe(userid);
				e.frame.setVisible(true);
			}
		});
		btnGoBack.setForeground(new Color(0, 51, 153));
		btnGoBack.setFont(new Font("Times New Roman", Font.BOLD, 22));
		btnGoBack.setBounds(32, 21, 145, 42);
		frame.getContentPane().add(btnGoBack);
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select ingredients from rrecipe where name='"+name+"'";
			ResultSet r=st1.executeQuery(sql);
		    while (r.next()){
			t2.setText(r.getString(1));
		    }
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		
	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select recipe from rrecipe where name='"+name+"'";
			ResultSet r=st1.executeQuery(sql);
		    while (r.next()){
			t3.setText(r.getString(1));
		    }
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String rname=t1.getText();
				String ing=t2.getText();
				String recipe=t3.getText();

				String url="jdbc:oracle:thin:@localhost:1521:xe";
				String username="username";
				String password="password";
				
				try
				{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection(url,username,password);
				
			
				String query="update rrecipe set name='"+rname+"',ingredients='"+ing+"',recipe='"+recipe+"' where name='"+name+"' ";
				PreparedStatement sta=con.prepareStatement(query);
				
				int count=sta.executeUpdate();
				sta.close();
				con.close();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				frame.dispose();
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st1=con1.createStatement();
					String sql = "select userno from rrecipe where name='"+name+"'";
					ResultSet r=st1.executeQuery(sql);
				    while (r.next()){
					String a=r.getString(1);
					int ia=Integer.parseInt(a);
					EditRecipe e=new EditRecipe(ia);
					e.frame.setVisible(true);
				    }
				st1.close();
			    con1.close();
				}	
			    catch(Exception e)
					{
						e.printStackTrace();
					}
			}
		});
		
	}
}
