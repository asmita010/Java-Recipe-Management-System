import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;

public class AdminSearch {

	 JFrame frame;
	private JTextField t;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminSearch window = new AdminSearch();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminSearch() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton button = new JButton("Go Back To Main Page");
		button.setForeground(new Color(0, 51, 153));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				AdminMenu u=new AdminMenu();
				u.frame.setVisible(true);
			}
		});
		button.setFont(new Font("SansSerif", Font.PLAIN, 20));
		button.setBounds(29, 28, 251, 29);
		frame.getContentPane().add(button);
		
		t = new JTextField();
		t.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		t.setColumns(10);
		t.setBounds(503, 34, 638, 32);
		frame.getContentPane().add(t);
		
		JButton button_1 = new JButton("Search");
		button_1.setFont(new Font("SansSerif", Font.PLAIN, 20));
		button_1.setBounds(503, 34, 113, 29);
		frame.getContentPane().add(button_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(105, 119, 1136, 456);
		frame.getContentPane().add(scrollPane);
		
		JList list = new JList();
		list.setFont(new Font("Shruti", Font.BOLD, 18));
		scrollPane.setViewportView(list);
		
		JButton button_2 = new JButton("View Recipe");
		button_2.setForeground(new Color(0, 51, 153));
		
		button_2.setFont(new Font("SansSerif", Font.PLAIN, 20));
		button_2.setBounds(596, 605, 153, 37);
		frame.getContentPane().add(button_2);
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select name from rrecipe";
			ResultSet r=st1.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    list.setModel(dlm);
		    
		    JButton button_3 = new JButton("Search");
		    button_3.setForeground(new Color(0, 51, 153));
		    button_3.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e) {
		    		String a=t.getText();
					try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
						Statement st1=con1.createStatement();
						String sql = "select name from rrecipe where lower(name) like lower('%"+a+"%')";
						ResultSet r=st1.executeQuery(sql);
						DefaultListModel dlm=new DefaultListModel();
					    while (r.next()){
						dlm.addElement(r.getString(1));
					    }
					    list.setModel(dlm);
					}
					    catch(Exception ae)
					    {
					    	ae.printStackTrace();
					    }
		    	}
		    });
		    button_3.setFont(new Font("SansSerif", Font.PLAIN, 20));
		    button_3.setBounds(1187, 33, 113, 29);
		    frame.getContentPane().add(button_3);
		    
		    JLabel label = new JLabel("Recipez");
		    label.setForeground(new Color(255, 204, 0));
		    label.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		    label.setBounds(1206, 627, 119, 37);
		    frame.getContentPane().add(label);
		}
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
		
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				String a=(String) list.getSelectedValue();
				NewAdminSearch n=new NewAdminSearch(a);
				n.frame.setVisible(true);
			}
		});
		
		
		
	}
}
