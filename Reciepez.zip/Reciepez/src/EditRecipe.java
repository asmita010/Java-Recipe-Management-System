import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class EditRecipe {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditRecipe window = new EditRecipe(0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EditRecipe(int userid) {
		initialize(userid);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int userid) {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblEditRecipe = new JLabel("Edit Recipe");
		lblEditRecipe.setForeground(new Color(204, 0, 153));
		lblEditRecipe.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 32));
		lblEditRecipe.setBounds(588, 25, 170, 48);
		frame.getContentPane().add(lblEditRecipe);
		
		JLabel lblSelectARecipe = new JLabel("Select a recipe from the list and click on Edit Recipe'");
		lblSelectARecipe.setForeground(new Color(153, 153, 0));
		lblSelectARecipe.setFont(new Font("Shruti", Font.BOLD, 25));
		lblSelectARecipe.setBounds(367, 84, 611, 37);
		frame.getContentPane().add(lblSelectARecipe);
		
		JList list = new JList();
		list.setFont(new Font("Arial Narrow", Font.PLAIN, 23));
		list.setBounds(94, 158, 1180, 404);
		frame.getContentPane().add(list);
		
		
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select name from rrecipe where userno='"+userid+"'";
			ResultSet r=st1.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    list.setModel(dlm);
		    
		  
		    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
		
		
		
		
		
		
		
		
		
		
		
		JButton btnEditRecipe = new JButton("Edit Recipe");
		btnEditRecipe.setForeground(new Color(0, 51, 153));
		btnEditRecipe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String a=(String) list.getSelectedValue();
				frame.dispose();
				NewEditRecipe n=new NewEditRecipe(userid,a);
				n.frame.setVisible(true);
			}
		});
		btnEditRecipe.setFont(new Font("Arial", Font.BOLD, 21));
		btnEditRecipe.setBounds(585, 619, 176, 37);
		frame.getContentPane().add(btnEditRecipe);
		
		JButton btnNewButton = new JButton("Go Back To Main Page");
		btnNewButton.setForeground(new Color(0, 51, 153));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				UserMenu u=new UserMenu(userid);
				u.frame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Shruti", Font.PLAIN, 22));
		btnNewButton.setBounds(38, 29, 265, 37);
		frame.getContentPane().add(btnNewButton);
		
		JLabel label = new JLabel("Recipez");
		label.setForeground(new Color(255, 204, 0));
		label.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		label.setBounds(1217, 634, 119, 37);
		frame.getContentPane().add(label);
		
		
		
		
	}

}
