import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;

public class SearchRecipe {

	 JFrame frame;
	private JTextField t;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchRecipe window = new SearchRecipe(0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SearchRecipe(int userid) {
		initialize(userid);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int userid) {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		t = new JTextField();
		t.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		t.setBounds(503, 30, 638, 32);
		frame.getContentPane().add(t);
		t.setColumns(10);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.setForeground(new Color(0, 51, 153));
		
		btnNewButton.setFont(new Font("SansSerif", Font.PLAIN, 20));
		btnNewButton.setBounds(1187, 33, 113, 29);
		frame.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(107, 162, 1136, 439);
		frame.getContentPane().add(scrollPane);
		
		JList list = new JList();
		list.setForeground(new Color(153, 51, 102));
		list.setFont(new Font("Shruti", Font.BOLD, 22));
		scrollPane.setViewportView(list);
		
		JButton btnGoBackTo = new JButton("Go Back To Main Page");
		btnGoBackTo.setForeground(new Color(0, 51, 153));
		btnGoBackTo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				UserMenu u=new UserMenu(userid);
				u.frame.setVisible(true);
				
			}
		});
		btnGoBackTo.setFont(new Font("SansSerif", Font.PLAIN, 20));
		btnGoBackTo.setBounds(29, 28, 251, 29);
		frame.getContentPane().add(btnGoBackTo);
		
		JButton btnViewRecipe = new JButton("View Recipe");
		btnViewRecipe.setForeground(new Color(0, 51, 153));
		
		btnViewRecipe.setFont(new Font("SansSerif", Font.PLAIN, 20));
		btnViewRecipe.setBounds(596, 628, 153, 29);
		frame.getContentPane().add(btnViewRecipe);
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select name from rrecipe";
			ResultSet r=st1.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    list.setModel(dlm);
		    
		    JLabel label = new JLabel("Recipez");
		    label.setForeground(new Color(255, 204, 0));
		    label.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		    label.setBounds(1217, 639, 119, 37);
		    frame.getContentPane().add(label);
		    
		    JLabel lblNewLabel = new JLabel("Recipes");
		    lblNewLabel.setForeground(new Color(255, 153, 0));
		    lblNewLabel.setFont(new Font("SansSerif", Font.BOLD, 28));
		    lblNewLabel.setBounds(607, 107, 132, 32);
		    frame.getContentPane().add(lblNewLabel);
		}
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String a=t.getText();
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st1=con1.createStatement();
					String sql = "select name from rrecipe where lower(name) like lower('%"+a+"%')";
					ResultSet r=st1.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    list.setModel(dlm);
				}
				    catch(Exception e)
				    {
				    	e.printStackTrace();
				    }
			}
		});
	
		btnViewRecipe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String a=(String) list.getSelectedValue();
				frame.dispose();
				NewSearch s=new NewSearch(userid,a);
				s.frame.setVisible(true);
				
			}
		});
		
		
	}
}
