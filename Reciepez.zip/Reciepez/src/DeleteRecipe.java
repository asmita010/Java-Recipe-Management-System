import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class DeleteRecipe {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteRecipe window = new DeleteRecipe(0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DeleteRecipe(int userid) {
		initialize(userid);
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int userid) {
		frame = new JFrame();
		frame.setBounds(0, 0,1362 , 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JList list = new JList();
		list.setFont(new Font("Arial Narrow", Font.PLAIN, 23));
		list.setBounds(80, 174, 1180, 404);
		frame.getContentPane().add(list);
		
		JLabel lblNewLabel = new JLabel("Delete Recipe");
		lblNewLabel.setForeground(new Color(204, 102, 153));
		lblNewLabel.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 32));
		lblNewLabel.setBounds(489, 25, 223, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Select a recipe from the list and click on 'Delete Recipe'");
		lblNewLabel_1.setForeground(new Color(153, 153, 0));
		lblNewLabel_1.setFont(new Font("Shruti", Font.BOLD, 25));
		lblNewLabel_1.setBounds(351, 96, 643, 37);
		frame.getContentPane().add(lblNewLabel_1);
		
		  JButton btnNewButton = new JButton("Delete Recipe");
		  btnNewButton.setForeground(new Color(0, 51, 153));
		  btnNewButton.addMouseListener(new MouseAdapter() {
		  	@Override
		  	public void mouseClicked(MouseEvent arg0) {
		  		try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
					Statement st1=con1.createStatement();
					String sql = "select name from rrecipe where userno='"+userid+"'";
					ResultSet r=st1.executeQuery(sql);
					DefaultListModel dlm=new DefaultListModel();
				    while (r.next()){
					dlm.addElement(r.getString(1));
				    }
				    list.setModel(dlm);
				    
				  
				    
				st1.close();
			    con1.close();
				}	
			    catch(Exception e)
					{
						e.printStackTrace();
					}
		  	}
		  });
		    btnNewButton.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e) {
		    		String s=(String) list.getSelectedValue();
		    		
		    		 String url="jdbc:oracle:thin:@localhost:1521:xe";
						String username="username";
						String password="password";
						String userno=String.valueOf(userid);
						try
						{
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection con = DriverManager.getConnection(url,username,password);
						
					
						String query="delete from rrecipe where name='"+s+"'";

						
						PreparedStatement sta=con.prepareStatement(query);
						
						int count=sta.executeUpdate();
						sta.close();
						con.close();
						}
						catch(Exception ea)
						{
							ea.printStackTrace();
						}
						frame.dispose();
						UserMenu u=new UserMenu(userid);
						u.frame.setVisible(true);
					
		    	}
		    });
		    btnNewButton.setFont(new Font("Arial", Font.BOLD, 21));
		    btnNewButton.setBounds(579, 601, 187, 37);
		    frame.getContentPane().add(btnNewButton);

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","username","password");
			Statement st1=con1.createStatement();
			String sql = "select name from rrecipe where userno='"+userid+"'";
			ResultSet r=st1.executeQuery(sql);
			DefaultListModel dlm=new DefaultListModel();
		    while (r.next()){
			dlm.addElement(r.getString(1));
		    }
		    list.setModel(dlm);
		    
		    JButton btnNewButton_1 = new JButton("Go Back To Main Page");
		    btnNewButton_1.setForeground(new Color(0, 51, 153));
		    btnNewButton_1.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e) {
		    		frame.dispose();
					UserMenu u=new UserMenu(userid);
					u.frame.setVisible(true);
		    	}
		    });
		    btnNewButton_1.setFont(new Font("Shruti", Font.PLAIN, 22));
		    btnNewButton_1.setBounds(31, 25, 271, 31);
		    frame.getContentPane().add(btnNewButton_1);
		    
		    JLabel label = new JLabel("Recipez");
		    label.setForeground(new Color(255, 204, 0));
		    label.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		    label.setBounds(1205, 626, 119, 37);
		    frame.getContentPane().add(label);
		    
		  
		    
		st1.close();
	    con1.close();
		}	
	    catch(Exception e)
			{
				e.printStackTrace();
			}
	}
}
